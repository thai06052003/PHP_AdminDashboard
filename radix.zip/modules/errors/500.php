<?php 
    if ( ! defined("_INCODE") ) die('Access Deined...'); 
?>
<div class="debug-wrapper" style="width: 600px; padding: 20px 30px; text-align: center; margin: 0 auto">
    <h1 style="text-align: center;">HTTP 500 ERROR</h1>
    <h3 style="text-align: center;">Đã có lỗi sảy ra liên quan đến Server, vui lòng kiểm tra lại</h3>
</div>