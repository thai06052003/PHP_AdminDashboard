<?php 
    if ( ! defined("_INCODE") ) die('Access Deined...'); 
?>
<h1 style="text-align: center;">PAGE NOT FOUND</h1>